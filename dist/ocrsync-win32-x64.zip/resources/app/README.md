# OCRSync

![Main Screen Synced](https://i.imgur.com/O08sASX.png)

This small app allows you to stay updated with the music repository of [OverClocked ReMix](http://ocremix.org/).

![Sync Screen Done](https://i.imgur.com/b5RhuoX.png)

## How to use

For now, you will need to have npm installed in your system and execute the following
