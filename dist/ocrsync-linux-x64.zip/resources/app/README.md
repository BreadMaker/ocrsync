# OCRSync

![Sync Screen Done](https://i.imgur.com/b5RhuoX.png)

This small app allows you to stay updated with the music repository of [OverClocked ReMix](http://ocremix.org/).

## How to use

You will find ready-to-go binaries for your platform in the `dist/` folder. Just unzip and execute `ocrsync`.

## How to contribute

If you find some unexpected behavior, please [report it as an issue](https://gitlab.com/breadmaker/ocrsync/issues/new).
